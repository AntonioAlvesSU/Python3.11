import pyautogui
import time

time.sleep(5)
print(pyautogui.position())  # pegar a posição do mouse para saber onde clicar
pyautogui.scroll(-200)  # testar quanto de scroll

